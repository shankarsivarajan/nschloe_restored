## Missing data

- Yue Qiao, Roy S. Berns, Lisa Reniff, Ethan Montag,
  [Visual determination of hue suprathreshold color-difference
  tolerances.](<https://doi.org/10.1002/(SICI)1520-6378(199810)23:5<302::AID-COL6>3.0.CO;2-%23>)
  Emailed <berns@cis.rit.edu> (2018-02-12).

- Dong-Ho Kim, Eun Kyoung Cho, Jae Pil Kim,
  [Evaluation of CIELAB-based colour-difference formulae using a new
  dataset](https://doi.org/10.1002/col.1052).
  Emailed <donghokim@korea.com> (2018-02-13).

- Data from [Color difference evaluation for wide-color-gamut
  displays](https://doi.org/10.1364/JOSAA.394132)
