From

C. Alder, K. P. Chaing, T. F. Chong, E. Coates, A. A. Khalili and B. Rigg,
Uniform Chromaticity Scales - New Experimental Data,
J . Soc. Dyers Colour. 98, 14-20 (1982),
<https://doi.org/10.1111/j.1478-4408.1982.tb03602.x>.
