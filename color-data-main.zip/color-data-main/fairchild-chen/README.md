Table I of

Mark D. Fairchild and Ping-Hsu Chen,
Brightness, Lightness, and Specifying Color in High-Dynamic-Range Scenes and Images
Munsell Color Science Laboratory, Chester F. Carlson Center for Imaging Science,
Rochester Institute of Technology, Rochester, NY, USA 14623-5604,
<https://doi.org/10.1117/12.872075>.

For each table, the data is
evaluated lightness, XYZ100 coords
