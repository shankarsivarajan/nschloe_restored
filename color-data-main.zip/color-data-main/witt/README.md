In

Claudio Oleari, Manuel Melgosa, and Rafael Huertas,
Euclidean color-difference formula for small–medium color differences in log-compressed
OSA-UCS space,
Journal of the Optical Society of America A Vol. 26, Issue 1, pp. 121-134 (2009),
https://doi.org/10.1364/JOSAA.26.000121,

one reads:

In Witt’s dataset [20] the correct luminance factor of Yellow center #8 should be
Y10=69.62 and not 32.93, as given in Table A-I of the original article and in the
original COM dataset. This is a typographic misprint, which we have discussed with the
author, and it affected only the two color pairs named SETNAME Yellow 8 (i.e., pairs
286 and 287). In the current computations, the correct values are considered. For
Witt's dataset the background lightness was L\*=57.0, which is equivalent to Yb=24.9,
assuming the reference white Yn=100.
