import colorio

cs = colorio.cs.IPT
plt = colorio.data.Munsell().plot(cs, V=5)
plt.show()
