# Algorithmic improvements for the CIECAM02 and CAM16 color appearance models

This article is available on [arxiv.org](https://arxiv.org/abs/1802.06067).

Compile the LaTeX document with
```
make
```

### License
The sources of this article are published under the [CC-BY 4.0 license](https://creativecommons.org/licenses/by/4.0/).
