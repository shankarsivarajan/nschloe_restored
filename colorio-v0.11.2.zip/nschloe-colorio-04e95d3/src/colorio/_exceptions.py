class ColorioError(Exception):
    pass
