Data from

F. Ebner and M.D. Fairchild,
Finding Constant Hue Surfaces in Color Space,
SPIE/IS&T Electronic Imaging, (1998),
<https://doi.org/10.1117/12.298269>.
(Last Updated: Oct. 27, 1997)

Retrieved from <http://www.rit-mcsl.org/fairchild/CAM.html>.
