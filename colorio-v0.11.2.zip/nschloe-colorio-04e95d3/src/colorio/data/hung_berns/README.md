All data extracted from

Po-Chieh Hung, Roy S. Berns,
Determination of Constant Hue Loci for a CRT Gamut and Their Predictions Using
Color Appearance Spaces,
Color Research and Application, Volume 20, Issue 5 October 1995, Pages 285-295,
<https://doi.org/10.1002/col.5080200506>.

with the help of [tabula](https://github.com/tabulapdf/tabula).
