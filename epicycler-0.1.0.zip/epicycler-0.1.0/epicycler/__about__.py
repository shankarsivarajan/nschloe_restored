# -*- coding: utf-8 -*-
#

__author__ = u"Nico Schlömer"
__email__ = "nico.schloemer@gmail.com"
__copyright__ = u"Copyright (c) 2018, {} <{}>".format(__author__, __email__)
__credits__ = []
__license__ = "License :: OSI Approved :: MIT License"
__version__ = "0.1.0"
__maintainer__ = u"Nico Schlömer"
__status__ = "Development Status :: 3 - Alpha"
