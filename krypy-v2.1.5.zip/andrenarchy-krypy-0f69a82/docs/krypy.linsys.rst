:mod:`krypy.linsys` - Linear Algebraic Systems Solver
=====================================================

The linsys module provides functions for the solution of linear algebraic
systems.

.. automodule:: krypy.linsys
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: krypy.linsys._KrylovSolver
    :members:
