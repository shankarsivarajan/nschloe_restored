:mod:`krypy.recycling.evaluators` - evaluators for deflation vector candidates
==============================================================================

.. automodule:: krypy.recycling.evaluators 
    :members:
    :undoc-members:
    :show-inheritance:
