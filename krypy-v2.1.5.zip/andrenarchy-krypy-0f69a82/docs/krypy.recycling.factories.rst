:mod:`krypy.recycling.factories` - deflation vector factories
=============================================================

.. automodule:: krypy.recycling.factories
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: krypy.recycling.factories._DeflationVectorFactory
    :members:
    :private-members:
