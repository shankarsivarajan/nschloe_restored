:mod:`krypy.recycling.generators` - generators for deflation vector candidates
==============================================================================

.. automodule:: krypy.recycling.generators
    :members:
    :undoc-members:
    :show-inheritance:

.. autoclass:: krypy.recycling.generators._RitzSubsetsGenerator
    :members:
    :private-members:
