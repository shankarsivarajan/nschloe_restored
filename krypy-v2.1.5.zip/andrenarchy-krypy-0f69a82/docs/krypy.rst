krypy Package
=============

.. currentmodule:: krypy

.. toctree::

    krypy.linsys
    krypy.deflation
    krypy.recycling
    krypy.utils

Subpackages
-----------

.. toctree::

    krypy.tests

