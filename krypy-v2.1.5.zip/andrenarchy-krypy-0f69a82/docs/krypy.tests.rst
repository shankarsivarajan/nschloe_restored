tests Package
=============

:mod:`tests` Module
-------------------

.. automodule:: krypy.tests.test_linsys
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: krypy.tests.test_utils
    :members:
    :undoc-members:
    :show-inheritance:
