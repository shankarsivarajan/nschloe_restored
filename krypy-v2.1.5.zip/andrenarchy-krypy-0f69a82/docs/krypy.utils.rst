:mod:`krypy.utils` - Krylov Subspace Utilities
==============================================

The utils module provides helper functions for common tasks in the
process of solving linear algebraic systems.

.. automodule:: krypy.utils
    :members:
    :undoc-members:
    :special-members:
    :exclude-members: __dict__, __weakref__, __module__, __init__
    :show-inheritance:
