* `square.su2` : from https://su2code.github.io/docs_v7/Mesh-File/
* `mixgrid.su2` : generated using http://ossanworld.com/cfdbooks/cfdcodes/mixgrid_cube_v5.f90
