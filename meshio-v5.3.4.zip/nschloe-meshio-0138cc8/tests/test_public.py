import meshio


def test_public_attributes():
    # Just make sure this is here
    meshio.extension_to_filetypes
