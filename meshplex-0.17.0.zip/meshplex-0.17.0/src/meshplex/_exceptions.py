class MeshplexError(Exception):
    pass
