If you're having problems optimizing a mesh, remember to

 - [ ] specify your optimesh version (`optimesh -v`),
 - [ ] specify what command you were running,
 - [ ] attach the mesh (or even better: a small mesh that reproduces the problem).

This will enable other people to reproduce and fix the problem.
