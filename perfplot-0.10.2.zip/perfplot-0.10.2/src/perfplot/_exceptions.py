class PerfplotError(Exception):
    pass
