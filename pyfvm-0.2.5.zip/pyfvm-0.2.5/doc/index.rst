.. PyFVM documentation master file, created by
   sphinx-quickstart on Tue Feb 25 11:45:44 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to PyFVM's documentation!
==================================

Contents:

.. toctree::
   :maxdepth: 2

   pyfvm.mesh_tri
   pyfvm.mesh_tetra
   pyfvm.reader


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

