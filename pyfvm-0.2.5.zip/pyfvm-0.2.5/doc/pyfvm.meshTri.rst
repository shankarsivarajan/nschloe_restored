:mod:`pyfvm.mesh_tri`
=====================

.. automodule:: pyfvm.mesh_tri
    :members:
    :undoc-members:
    :show-inheritance:

References
==========

.. bibliography:: refs.bib
   :all:
