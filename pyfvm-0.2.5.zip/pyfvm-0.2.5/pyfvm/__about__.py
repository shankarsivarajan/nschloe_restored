# -*- coding: utf-8 -*-
#
__author__ = u"Nico Schlömer"
__author_email__ = "nico.schloemer@gmail.com"
__copyright__ = u"Copyright (c) 2012-2018, {} <{}>".format(__author__, __author_email__)
__license__ = "License :: OSI Approved :: MIT License"
__version__ = "0.2.5"
__status__ = "Development Status :: 4 - Beta"
