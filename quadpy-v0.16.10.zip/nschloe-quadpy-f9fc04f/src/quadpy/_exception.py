class QuadpyError(Exception):
    pass
