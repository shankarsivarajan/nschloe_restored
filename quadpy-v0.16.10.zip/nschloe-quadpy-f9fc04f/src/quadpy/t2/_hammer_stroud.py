from ._hammer_marlowe_stroud import hammer_marlowe_stroud_1 as hammer_stroud_2
from ._hammer_marlowe_stroud import hammer_marlowe_stroud_4 as hammer_stroud_3

# source = article(
#     authors=["Preston C. Hammer", "Arthur H. Stroud"],
#     title="Numerical Evaluation of Multiple Integrals II",
#     journal="Math. Comp.",
#     volume="12",
#     year="1958",
#     pages="272-280",
#     url="https://doi.org/10.1090/S0025-5718-1958-0102176-6",
# )

__all__ = ["hammer_stroud_2", "hammer_stroud_3"]
