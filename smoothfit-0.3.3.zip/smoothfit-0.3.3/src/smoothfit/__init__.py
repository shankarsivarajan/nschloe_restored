from .__about__ import __version__
from .main import fit, fit1d

__all__ = [
    "__version__",
    #
    "fit",
    "fit1d",
]
