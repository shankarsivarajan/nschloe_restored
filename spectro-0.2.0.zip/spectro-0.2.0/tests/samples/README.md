The file `Yamaha-V50-Ride-Pattern-120bpm.wav` is taken from
https://freewavesamples.com/yamaha-v50-ride-pattern-120-bpm.
