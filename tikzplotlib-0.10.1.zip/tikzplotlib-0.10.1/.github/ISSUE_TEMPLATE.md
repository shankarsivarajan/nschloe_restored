Please provide a minimal working example (MWE) that shows what isn't working as
expected. Needed is

  * the Python code,
  * the output TeX (Pgfplots), and
  * the expected TeX (Pgfplots).

Perhaps the [Pgfplots manual](http://mirror.ctan.org/tex-archive/graphics/pgf/contrib/pgfplots/doc/pgfplots.pdf)
is helpful here.
