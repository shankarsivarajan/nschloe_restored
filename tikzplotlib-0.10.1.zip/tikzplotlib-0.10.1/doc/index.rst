.. tikzplotlib documentation master file, created by
   sphinx-quickstart on Thu Feb  4 12:49:27 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to tikzplotlib's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Methods
=======

.. automodule:: tikzplotlib
  :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
